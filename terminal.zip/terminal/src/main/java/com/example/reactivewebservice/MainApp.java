package com.example.reactivewebservice;

public class MainApp {
    public static void main(String[] args) {
        //Create a new command line instance
        CommandLine commandLine = new CommandLine("http://localhost:8080");
        commandLine.start();
    }
}
